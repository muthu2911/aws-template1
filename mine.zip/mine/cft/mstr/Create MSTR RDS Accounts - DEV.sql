--
-- Infra 572068
--
-- Account Name                          Database          Access Required 
-- svc_ie_mysql_mstr_metadata_dev        MySQL RDS         Admin 
-- svc_ie_mysql_mstr_statistics_dev      MySQL RDS         Admin 
-- svc_ie_mysql_mstr_history_dev         MySQL RDS         Admin 



-- MSTR RDS Endpoint:
-- intl-ireland-microstrategy-rds-mysql-dev.cg8wwjoubmfs.eu-west-1.rds.amazonaws.com

-- Create metadata service account:
CREATE USER 'svc_ie_mysql_mstr_metadata_dev'@'localhost' IDENTIFIED BY 'examp!e2v$Ew';
CREATE USER 'svc_ie_mysql_mstr_metadata_dev'@'%' IDENTIFIED BY 'examp!e2v$Ew';

GRANT ALL PRIVILEGES ON Metadata.* TO 'svc_ie_mysql_mstr_metadata_dev'@'localhost';


-- Create statistics service account:
CREATE USER 'svc_ie_mysql_mstr_statistics_dev'@'localhost' IDENTIFIED BY 'cerTa!n3aRea';
CREATE USER 'svc_ie_mysql_mstr_statistics_dev'@'%' IDENTIFIED BY 'cerTa!n3aRea';

GRANT ALL PRIVILEGES ON Statistics.* TO 'svc_ie_mysql_mstr_statistics_dev'@'localhost';


-- Create history service account:
CREATE USER 'svc_ie_mysql_mstr_history_dev'@'localhost' IDENTIFIED BY 'reLated4!cArt';
CREATE USER 'svc_ie_mysql_mstr_history_dev'@'%' IDENTIFIED BY 'reLated4!cArt';

GRANT ALL PRIVILEGES ON History.* TO 'svc_ie_mysql_mstr_history_dev'@'localhost';



